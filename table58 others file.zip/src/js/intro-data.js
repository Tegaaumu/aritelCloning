// wrap in UMD
(function() {
